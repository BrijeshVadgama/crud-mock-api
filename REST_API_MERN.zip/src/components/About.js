import React from "react";

function About() {
  return <h1>This is About Us Page In this file</h1>;
}

export default About;
